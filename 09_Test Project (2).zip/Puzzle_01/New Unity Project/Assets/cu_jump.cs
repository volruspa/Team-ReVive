﻿using UnityEngine;
using System.Collections;

public class cu_jump : MonoBehaviour {

    public int mJump=5;
    public Rigidbody rb;

	void Start () 
    {
     
        rb = GetComponent<Rigidbody>();
	}
	
	void Update () {
	 
        if(Input.GetButtonDown("Jump"))
        {
            rb.velocity = new Vector3(0, mJump, 0);
        }
	}
}
